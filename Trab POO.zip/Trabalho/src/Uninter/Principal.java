// Aluna: Kamilly Vitória Gonçalves Silva
// RU: 5013966
package Uninter;

public class Principal {
	
	public static void main(String[] args) {
		Menu menu = new Menu();
		menu.mostrarMenuPrincipal();
	}
}