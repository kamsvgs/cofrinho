package Uninter;

public abstract class Moeda { // Armazena o valor da moeda
	
	protected double valor;
	
	public abstract void info();
	public abstract double converter();

}
