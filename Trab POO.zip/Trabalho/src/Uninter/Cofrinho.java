package Uninter;

import java.util.ArrayList;

public class Cofrinho {
	
	private ArrayList<Moeda> listaMoedas; // Lista para armazenar as moedas no cofrinho
	
	public Cofrinho() {
		this.listaMoedas = new ArrayList<>(); // Inicializa a lista de moedas como uma lista vazia
	}
	
	public void adicionar (Moeda moeda) {
		this.listaMoedas.add(moeda); // Adiciona uma moeda na lista de moedas
	}
	
	public void remove (Moeda moeda) {
		this.listaMoedas.remove(moeda); // Remove uma moeda da lista de moedas
	}
	
	public void listagemMoedas() {
		// Verifica se o cofrinho está vazio e imprime a mensagem
		if (this.listaMoedas.isEmpty()) {
			System.out.println("Sem moedas no cofrinho :(");
			return; 
		}
		
		// Verifica a lista de moedas e exibe suas informações
		for (Moeda moeda : this.listaMoedas) {
			moeda.info();
		}
	}
	
	public double totalConvertido() {
		// Verifica se o cofrinho está vazio
		if (this.listaMoedas.isEmpty()) {
			return 0;
		}
		double valorAcumulado = 0; // Variável para armazenar o valor total convertido
		
		
		for (Moeda moeda : this.listaMoedas) {
			valorAcumulado = valorAcumulado + moeda.converter();
		}
		return valorAcumulado; // Retorna o valor total convertido em reais
		
	}
}
